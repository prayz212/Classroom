<?php
session_start();
require_once "./mvc/Bridge.php";
//if (isset($_SESSION['loggedIn'])) {
//    $myApp = new App();
//} else {
//    $login = new App2();
//}

$myApp = new App();





?>